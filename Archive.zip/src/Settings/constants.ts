export const GET_FILTER = 'olipie/Settings/GET_FILTER';
export const SET_FILTER = 'olipie/Settings/SET_FILTER';
export const UPDATE_FILTER = 'olipie/Settings/UPDATE_FILTER';
export const SET_FILTER_SUCCESS = 'olipie/Settings/SET_FILTER_SUCCESS';