export enum Mode {
    Default,
    Watch,
    Monitor,
    LoggedOut
}

export const SET_MODE = 'olipie/App/SET_MODE';
export const SET_CURRENT_ACCOUNT = 'olipie/App/SET_CURRENT_ACCOUNT';
export const SET_CURRENT_USER = 'olipie/App/SET_CURRENT_USER';