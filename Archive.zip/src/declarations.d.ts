declare module 'material-ui-search-bar';
declare module 'react-youtube';
declare module 'react-redux';