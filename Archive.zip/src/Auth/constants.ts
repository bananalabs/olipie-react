export const ADD_ACCOUNT = 'olipie/Auth/ADD_ACCOUNT';
export const LOGOUT = 'olipie/Auth/LOGOUT';