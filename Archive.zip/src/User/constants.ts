export const GET_USERS = 'olipie/User/GET_USERS';
export const GET_USERS_SUCCESS = 'olipie/User/GET_USERS_SUCCESS';
export const ADD_USER = 'olipie/User/ADD_USER';
export const UPDATE_USER = 'olipie/User/UPDATE_USER';
export const ADD_USER_SUCCESS = 'olipie/User/ADD_USER_SUCCESS';
export const UPDATE_USER_SUCCESS = 'olipie/User/UPDATE_USER_SUCCESS';