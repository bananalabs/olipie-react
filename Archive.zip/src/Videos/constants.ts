export const GET_VIDEOS = 'olipie/Videos/GET_VIDEOS';
export const SET_VIDEOS = 'olipie/Videos/SET_VIDEOS';
export const ADD_VIDEO_TO_HISTORY = 'olipie/Videos/ADD_VIDEO_TO_HISTORY';
export const UPDATE_VIDEO = 'olipie/Videos/UPDATE_VIDEO';